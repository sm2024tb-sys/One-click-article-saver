function getArticleData() {
  const title = document.title || 'Untitled Article';
  const fullUrl = window.location.href || '';
  // safer excerpt extraction with meta fallbacks and safe substring
  const metaDesc = document.querySelector('meta[name="description"]')?.content
                 || document.querySelector('meta[property="og:description"]')?.content
                 || '';
  const firstPText = document.querySelector('p')?.innerText ?? '';
  const excerpt = (metaDesc || firstPText).slice(0, 200);
  return { title, url: fullUrl, excerpt, fullUrl };
}