SAVE ARTICLE EXTENSION v1.0.0
================================

WHAT IT DOES:
Save and share articles instantly to WhatsApp, Gmail, Twitter, Telegram, or send the article to your own Gmail inbox.

IMPORTANT: OAuth for "Send to my inbox"
- Sending directly to your Gmail inbox requires a Google OAuth client ID.
- You must register an OAuth client in Google Cloud Console and set the redirect URI to the value returned by chrome.identity.getRedirectURL().
- Set GOOGLE_OAUTH_CLIENT_ID in background.js before using "Send to my inbox".

INSTALLATION FOR TESTING:
1. Extract files to a folder
2. Open chrome://extensions/
3. Enable "Developer mode"
4. Click "Load unpacked" and select the folder
5. If using "Send to my inbox": register OAuth client and set client_id in background.js, then reload the extension

FILES INCLUDED:
- manifest.json
- background.js (injector + OAuth + message handlers)
- content.js (DOM + UI)
- Style.css (UI styles)
- Readme.txt
- PRIVACY_POLICY.txt
- LICENSE
- icon.png

PERMISSIONS:
- The extension needs:
  - scripting, activeTab, identity, storage
  - host permission for https://www.googleapis.com/* (to call Gmail API)

PRIVACY:
- OAuth tokens are used locally by the extension only to send the message-to-self email.
- No external servers are used.

LICENSE: MIT