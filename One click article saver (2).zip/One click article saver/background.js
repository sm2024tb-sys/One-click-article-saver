chrome.action.onClicked.addListener(async (tab) => {
  try {
    const url = tab?.url ?? '';
    // allow only http(s) pages
    if (!/^https?:\/\//i.test(url)) {
      console.warn('One click article saver: unsupported page URL, skipping injection:', url);
      return;
    }

    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['Style.css'] });
    } catch (e) {
      console.warn('CSS injection failed (CSP?)', e);
    }

    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => { if (window.showAppPicker) window.showAppPicker(); } });
    } catch (e) {
      console.error('Script injection failed', e);
    }
  } catch (err) {
    console.error(err);
  }
});

// Add this to handle sending message-to-self via Gmail
const GOOGLE_OAUTH_CLIENT_ID = 'REPLACE_WITH_YOUR_CLIENT_ID.apps.googleusercontent.com'; // TODO: set your client id
const GMAIL_SCOPE = 'https://www.googleapis.com/auth/gmail.send';

async function launchGmailAuth() {
  const redirectUri = chrome.identity.getRedirectURL();
  const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  authUrl.searchParams.set('client_id', GOOGLE_OAUTH_CLIENT_ID);
  authUrl.searchParams.set('response_type', 'token'); // implicit flow to get access_token in fragment
  authUrl.searchParams.set('redirect_uri', redirectUri);
  authUrl.searchParams.set('scope', GMAIL_SCOPE);
  authUrl.searchParams.set('prompt', 'consent'); // force consent so token includes scope
  const redirect = await chrome.identity.launchWebAuthFlow({ url: authUrl.toString(), interactive: true });
  // redirect is a full URL with fragment like "#access_token=...&token_type=Bearer&expires_in=..."
  const hash = new URL(redirect).hash.substring(1);
  const params = new URLSearchParams(hash);
  const token = params.get('access_token');
  if (!token) throw new Error('No access_token returned from auth flow');
  return token;
}

function base64UrlEncode(str) {
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function sendGmail(accessToken, toEmail, subject, bodyText) {
  const raw =
    `To: ${toEmail}\r\n` +
    `Subject: ${subject}\r\n` +
    `Content-Type: text/plain; charset="UTF-8"\r\n\r\n` +
    `${bodyText}`;
  const encoded = base64UrlEncode(raw);
  const res = await fetch('https://www.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ raw: encoded })
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Gmail API error: ${res.status} ${text}`);
  }
  return res.json();
}

// Listen for messages from content script
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.action === 'send-to-self' && msg.payload) {
    (async () => {
      try {
        const token = await launchGmailAuth();
        const payload = msg.payload; // { title, fullUrl, excerpt }
        const subject = `Saved: ${payload.title}`;
        const body = `${payload.excerpt || ''}\n\n${payload.fullUrl}`;
        await sendGmail(token, 'me', subject, body); // 'me' sends to authenticated account
        sendResponse({ status: 'ok' });
      } catch (err) {
        console.error('send-to-self failed', err);
        sendResponse({ status: 'error', message: err.message });
      }
    })();
    // indicate we'll call sendResponse asynchronously
    return true;
  }
});

// Add this clean async message handler to perform the OAuth flow and send email
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.action !== 'send-to-self' || !msg.payload) return;

  (async () => {
    try {
      if (GOOGLE_OAUTH_CLIENT_ID.includes('REPLACE_WITH')) {
        throw new Error('Set GOOGLE_OAUTH_CLIENT_ID in background.js with your Google OAuth client ID.');
      }

      const token = await launchGmailAuth();
      const payload = msg.payload; // { title, fullUrl, excerpt }
      const subject = `Saved: ${payload.title}`;
      const body = `${payload.excerpt || ''}\n\n${payload.fullUrl}`;

      await sendGmail(token, 'me', subject, body); // 'me' sends to authenticated account
      sendResponse({ status: 'ok' });
    } catch (err) {
      console.error('send-to-self failed', err);
      sendResponse({ status: 'error', message: err?.message || String(err) });
    }
  })();

  // Indicate we'll respond asynchronously
  return true;
});