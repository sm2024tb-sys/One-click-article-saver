# 📜 Save Article Extension

> Share articles instantly to WhatsApp, Gmail, Twitter, and Telegram with one click!

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Chrome](https://img.shields.io/badge/chrome-compatible-brightgreen.svg)
![Firefox](https://img.shields.io/badge/firefox-compatible-orange.svg)

## ✨ Features

- 📱 **WhatsApp** - Share with contacts or groups
- 📧 **Gmail** - Send as email draft  
- 🐦 **Twitter** - Post as tweet with link
- ✈️ **Telegram** - Share via Telegram Web
- 🔒 **Privacy-First** - Zero data collection
- ⚡ **Lightweight** - No external dependencies
- 🎨 **Beautiful UI** - Clean, modern interface

## 🚀 Installation

### Chrome/Edge/Brave

1. Download the [latest release]https://github.com/sm2024tb-sys/One-click-article-saver.git
2. Extract the ZIP file
3. Open `chrome://extensions/`
4. Enable **Developer Mode** (toggle in top-right)
5. Click **Load Unpacked**
6. Select the extracted folder

### Firefox

1. Download the [latest release]https://github.com/sm2024tb-sys/One-click-article-saver.git
2. Extract the ZIP file
3. Open `about:debugging`
4. Click **This Firefox**
5. Click **Load Temporary Add-on**
6. Select `manifest.json` from the extracted folder

## 📖 Usage

1. Navigate to any article or webpage
2. Click the 📜 ancient scroll icon in your toolbar
3. Choose your preferred sharing platform
4. Share instantly!

## 🔒 Privacy

**We collect ZERO data.** Period.

- ❌ No tracking
- ❌ No analytics
- ❌ No external servers
- ❌ No data storage
- ✅ Everything stays on your device

Read our full [Privacy Policy](PRIVACY_POLICY.txt)

## 🛠️ Development

### Prerequisites
- Chrome/Firefox browser
- Basic knowledge of JavaScript

### Project Structure
one click article saver/
├── manifest.json          # Extension configuration
├── background.js          # Core functionality
├── icon.png              # Extension icon (48x48)
├── LICENSE               # MIT License
├── README.md             # This file
└── PRIVACY_POLICY.txt    # Privacy policy