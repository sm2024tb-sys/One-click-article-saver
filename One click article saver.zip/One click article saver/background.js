chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: saveArticle
  });
});

function saveArticle() {
  const title = document.title || 'Untitled Article';
  const url = encodeURIComponent(window.location.href);
  const excerpt = document.querySelector('meta[name="description"]')?.content || 
                  document.querySelector('p')?.innerText.substring(0, 200) || '';
  
  const modal = document.createElement('div');
  modal.style.cssText = `
    position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    z-index: 10000; font-family: -apple-system, system-ui, sans-serif; max-width: 400px;
  `;
  
  modal.innerHTML = `
    <h3 style="margin: 0 0 20px 0; font-size: 18px;">Save Article</h3>
    <p style="margin: 0 0 20px 0; font-size: 14px; color: #666; max-height: 60px; overflow: hidden;">${title}</p>
    <button data-service="whatsapp" style="width: 100%; padding: 12px; margin: 6px 0; background: #25D366; color: white; border: none; border-radius: 6px; font-size: 15px; cursor: pointer;">
      📱 WhatsApp
    </button>
    <button data-service="gmail" style="width: 100%; padding: 12px; margin: 6px 0; background: #EA4335; color: white; border: none; border-radius: 6px; font-size: 15px; cursor: pointer;">
      📧 Gmail
    </button>
    <button data-service="twitter" style="width: 100%; padding: 12px; margin: 6px 0; background: #1DA1F2; color: white; border: none; border-radius: 6px; font-size: 15px; cursor: pointer;">
      🐦 Twitter
    </button>
    <button data-service="telegram" style="width: 100%; padding: 12px; margin: 6px 0; background: #0088cc; color: white; border: none; border-radius: 6px; font-size: 15px; cursor: pointer;">
      ✈️ Telegram
    </button>
    <button id="closeModal" style="width: 100%; padding: 10px; margin: 12px 0 0 0; background: #f0f0f0; color: #333; border: none; border-radius: 6px; cursor: pointer;">
      Cancel
    </button>
  `;
  
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 9999;';
  
  document.body.appendChild(overlay);
  document.body.appendChild(modal);
  
  const services = {
    whatsapp: () => {
      const text = encodeURIComponent(`${title}\n\n${window.location.href}`);
      window.open(`https://wa.me/?text=${text}`, '_blank');
    },
    gmail: () => {
      const subject = encodeURIComponent(title);
      const body = encodeURIComponent(`${excerpt}\n\nRead more: ${window.location.href}`);
      window.open(`https://mail.google.com/mail/?view=cm&fs=1&su=${subject}&body=${body}`, '_blank');
    },
    twitter: () => {
      const text = encodeURIComponent(title);
      window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
    },
    telegram: () => {
      const text = encodeURIComponent(`${title}\n${window.location.href}`);
      window.open(`https://t.me/share/url?url=${url}&text=${text}`, '_blank');
    }
  };
  
  modal.addEventListener('click', (e) => {
    const service = e.target.getAttribute('data-service');
    if (service && services[service]) {
      services[service]();
      cleanup();
    }
  });
  
  const cleanup = () => {
    overlay.remove();
    modal.remove();
  };
  
  document.getElementById('closeModal').onclick = cleanup;
  overlay.onclick = cleanup;
}