SAVE ARTICLE EXTENSION v1.0.0
================================

WHAT IT DOES:
Save and share articles instantly to WhatsApp, Gmail, Twitter, or Telegram with one click.

INSTALLATION FOR TESTING:
1. Extract all files to a folder
2. Open chrome://extensions/
3. Enable "Developer mode"
4. Click "Load unpacked"
5. Select the extracted folder

FILES INCLUDED:
- manifest.json (Extension configuration)
- background.js (Core functionality)
- icon.png (48x48 ancient scroll icon)
- PRIVACY_POLICY.txt (Privacy policy)
- README.txt (This file)

PUBLISHING TO CHROME WEB STORE:
1. Zip all files together
2. Go to: https://chrome.google.com/webstore/devconsole
3. Pay $5 one-time developer fee
4. Upload the zip file
5. Fill in store listing details
6. Submit for review

FEATURES:
✅ Zero data collection
✅ No external servers
✅ Minimal permissions
✅ Works offline (until sharing)
✅ Manifest V3 compliant
✅ Privacy-focused

REQUIREMENTS:
- Chrome 88+ / Edge 88+ / Brave (any recent version)
- No API keys needed
- No accounts required

SUPPORT:
For issues or questions: [Your Email or GitHub]

LICENSE:
MIT License - See LICENSE file


Icon.png from Canva with Free content license agreement 
by Sketchify Turkey
https://www.canva.com/policies/content-license-agreement/